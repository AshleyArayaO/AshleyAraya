/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cr.ac.ucr.juegodeparchisc5c589.modelo;

import cr.ac.ucr.juegodeparchisc5c589.vista.GUICronometro;

/**
 *
 * @author Thinkpad P52
 */
public class HiloCronometro extends Thread {
    
    private boolean corriendo=true;
    private int segundos=0;
    private GUICronometro gui;

    public HiloCronometro(GUICronometro gui) {
        this.gui = gui;
    }
    
    
    public void detener(){
        this.corriendo=false;
    }
    
    @Override
    public void run(){
       while (corriendo){
           try {
               this.sleep(1000);
               this.segundos++;
               this.gui.setCronometro(""+segundos);
               System.out.println("Tiempo: "+segundos);
               
           } catch (InterruptedException ex) {
               System.err.println("Se interrumpio el hilo");
           }
       } 
    }
}